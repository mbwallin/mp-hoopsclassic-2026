Meadow Park Hoops Classic 2026 — Static Website
==============================================

Files:
- index.html        (main page)
- styles.css        (styling)
- script.js         (tiny helper)
- assets/meadow-park-logo.png
- events/*.ics      (calendar files)

Fastest way to put this live (no coding):
Option A — Netlify (drag-and-drop)
1) Go to netlify.com and create a free account
2) Click "Add new site" → "Deploy manually" (or "Sites" → "Deploy manually")
3) Drag the *contents* of this folder (or the ZIP) into the upload area
4) Netlify will instantly publish a live URL you can share

Option B — GitHub Pages (also free)
1) Create a GitHub account
2) Make a new repository named: meadow-park-hoops-classic-2026
3) Upload these files
4) In Settings → Pages, choose "Deploy from branch" (main / root)
5) Your site will go live at: https://<your-username>.github.io/meadow-park-hoops-classic-2026/

Edit:
Open index.html in any text editor, update details, then re-upload/redeploy.
